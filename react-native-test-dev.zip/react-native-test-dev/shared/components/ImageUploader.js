import React, { Component } from 'react';
import { View } from 'react-native';

export default class ImageUploader extends Component {
    render() {
        return (
            <View></View>
        )
    }
}