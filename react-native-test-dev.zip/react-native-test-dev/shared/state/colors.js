module.exports = {
  gray: "#979797",
  blue: "#0065AE",
  red: "#E9552F",
  grayDA: "#dadada",
  white: "#ffffff",
  gray97: "#979797",
  grayC4: "#C4C4C4"
};
